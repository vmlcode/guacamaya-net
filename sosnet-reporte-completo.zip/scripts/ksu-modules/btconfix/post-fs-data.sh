#!/system/bin/sh
# SOSNet btconfix — restore SELinux labels on per-user data dirs.
#
# KernelSU-Next kernel patch on this device leaves /data/user/0 and
# /data/user_de/0 with stray MLS categories (system_data_file:s0:c512,c768).
# The bluetooth domain runs with no categories, so the kernel denies `search`
# on these dirs at adapter bring-up. BT appears enabled=false in dumpsys and
# the controller never receives its MAC.
#
# restorecon -F forces the label back to system_data_file:s0 (no categories)
# which matches the sepolicy allow rule. Idempotent.

MODDIR=${0%/*}

# post-fs-data runs before selinux transitions for normal services; restorecon
# works in any mode. Loop a moment in case /data is still settling.
for i in 1 2 3 4 5; do
    [ -d /data/user/0 ] && [ -d /data/user_de/0 ] && break
    sleep 1
done

LOG=/data/local/tmp/btconfix.log
{
    echo "[$(date)] btconfix start"
    ls -laZd /data/user/0 /data/user_de/0 2>&1
    restorecon -F /data/user/0 /data/user_de/0 2>&1
    echo "[$(date)] after restorecon:"
    ls -laZd /data/user/0 /data/user_de/0 2>&1
    echo "[$(date)] btconfix done"
} >"$LOG" 2>&1

exit 0
