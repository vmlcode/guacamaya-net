# SOSNet KernelSU modules (device: Xiaomi Redmi Note 10 / sweet)

Modules live under `/data/adb/modules/<id>` once installed.

## btconfix

Restores correct SELinux context on `/data/user/0` and `/data/user_de/0`.

**Symptom without this module**: `dumpsys bluetooth_manager` shows
`enabled: false` / `state: OFF` right after `svc bluetooth enable`; the BT MAC
is reported with first three octets zeroed
(`00:00:00:5F:0A:68` instead of `9C:5A:81:5F:0A:68`); `dmesg` shows
`avc: denied { search } for comm="droid.bluetooth" name="0" dev="dm-5"
tcontext=u:object_r:system_data_file:s0:c512,c768 permissive=0`.

**Root cause**: the KernelSU-Next kernel patch (`4.14.356-openela-rc1-...`)
causes the per-user data dirs to be created/relabeled with isolated-service
MLS categories (`s0:c512,c768`). The `bluetooth` SELinux domain has no
categories, so `search` is denied and the BT stack fails to bring the adapter
up.

**Fix**: `restorecon -F /data/user/0 /data/user_de/0` strips the categories
back to `system_data_file:s0`, which `bluetooth` is allowed to search.

### Install

```sh
adb -s <xiaomi-serial> push scripts/ksu-modules/btconfix /data/local/tmp/btconfix
adb -s <xiaomi-serial> shell su -c '
  cp -r /data/local/tmp/btconfix /data/adb/modules/btconfix &&
  chmod 0700 /data/adb/modules/btconfix/post-fs-data.sh &&
  chmod 0644 /data/adb/modules/btconfix/module.prop'
adb -s <xiaomi-serial> reboot
```

After reboot, BT should come up clean (`enabled: true`, `state: ON`, full MAC)
without needing `setenforce 0`.

### Verification

```sh
adb -s <xiaomi-serial> shell '
  getenforce;                                    # expect Enforcing
  dumpsys bluetooth_manager | grep -E "enabled|state:|address" | head -4
  cat /data/local/tmp/btconfix.log               # confirm restorecon ran
'
```
