#!/usr/bin/env bash
# SOSNet — jury demo runner.
#
# Usage:
#   ./scripts/demo.sh setup        # build + install on both adb devices
#   ./scripts/demo.sh tamper       # generate tampered frame, push to /sdcard
#   ./scripts/demo.sh logcat       # stream colorized logcat from a device
#
# Set PHONE_A and PHONE_B to adb serials if multiple devices are connected:
#   PHONE_A=abc123 PHONE_B=def456 ./scripts/demo.sh setup

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PHONE_A="${PHONE_A:-}"
PHONE_B="${PHONE_B:-}"

adb_target() {
  local serial="$1"
  if [[ -n "$serial" ]]; then
    echo "-s $serial"
  else
    echo ""
  fi
}

case "${1:-help}" in

  setup)
    echo "[1/3] Build debug APK"
    JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk}" ./gradlew :app:assembleDebug
    APK="app/build/outputs/apk/debug/app-debug.apk"
    echo "[2/3] Install on phone A (${PHONE_A:-default})"
    adb $(adb_target "$PHONE_A") install -r "$APK" || true
    echo "[3/3] Install on phone B (${PHONE_B:-default})"
    adb $(adb_target "$PHONE_B") install -r "$APK" || true
    echo "Done. Open SOSNet on both phones."
    ;;

  tamper)
    echo "[1/2] Generate tampered frame (host-side)"
    python3 scripts/tamper_test.py
    echo "[2/2] Push JSON to phone B"
    adb $(adb_target "$PHONE_B") push /tmp/sosnet_test_frames.json /sdcard/sosnet_test_frames.json
    echo "Done. In the app: Debug > Load test frame (tampered)."
    ;;

  logcat)
    TARGET="${PHONE_B:-$PHONE_A}"
    echo "Streaming colorized logcat from ${TARGET:-default} (Ctrl-C to stop)"
    adb $(adb_target "$TARGET") logcat -v time -c 2>/dev/null || true
    adb $(adb_target "$TARGET") logcat -v time | python3 scripts/logcat_pretty.py
    ;;

  *)
    cat <<USAGE
SOSNet demo runner.

Commands:
  setup    Build APK and install on PHONE_A and PHONE_B (adb serials).
  tamper   Generate tampered frame, push JSON to /sdcard.
  logcat   Stream colorized logcat from PHONE_B (or PHONE_A).

Environment:
  PHONE_A   adb serial of broadcaster phone (optional if one device).
  PHONE_B   adb serial of observer phone (optional if one device).

Example:
  PHONE_A=emulator-5554 PHONE_B=emulator-5556 ./scripts/demo.sh setup
USAGE
    exit 1
    ;;

esac
